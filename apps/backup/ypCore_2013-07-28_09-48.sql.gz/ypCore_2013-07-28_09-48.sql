#SKD101|ypCore|11|2013.07.28 09:48:42|52|4|1|10|3|4|2|2|2|19|4|1

DROP TABLE IF EXISTS `yp_download_email_list`;
CREATE TABLE `yp_download_email_list` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `email` varchar(100) NOT NULL,
  `download` int(10) NOT NULL DEFAULT '1',
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `yp_download_email_list` VALUES
(1, 'duyet2000@gmail.com', 24, '2013-07-22 08:12:31'),
(2, 'yplitgroup@gmail.com', 4, '2013-07-22 08:21:13'),
(3, 'chibisan.net@gmail.com', 1, '2013-07-22 08:21:29'),
(4, 'yplitgroup@facebook.com', 1, '2013-07-22 08:21:42');

DROP TABLE IF EXISTS `yp_download_files`;
CREATE TABLE `yp_download_files` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `path` varchar(250) NOT NULL,
  `download` int(250) NOT NULL DEFAULT '1',
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `yp_download_files` VALUES
(1, 'source/ypCore.zip', 11, '2013-07-22 08:41:50');

DROP TABLE IF EXISTS `yp_download_list_waiting`;
CREATE TABLE `yp_download_list_waiting` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `code` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `file_id` int(50) NOT NULL,
  `active` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `yp_download_list_waiting` VALUES
(10, '91b60365dd3413189eca9f081b91fd8d', '', 1, 0),
(11, '5fcdcd24a97cf4dd04b670f46a91dc49', '', 1, 0),
(12, '3bf2ddf87f1d467105da047e3f092f1c', '', 1, 0),
(13, 'fda154462add355fdf97d8c841eb844b', '', 1, 0),
(14, '9614991dc8aaea35b155b82179a1c3b2', 'duyet2000@gmail.com', 1, 0),
(15, 'c70dc6e1ba239ec4422857908cdd3b6f', 'duyet2000@gmail.com', 1, 0),
(16, 'fc28ec2c917ae86325b78e1003cc35d3', 'duyet2000@gmail.com', 1, 0),
(17, 'dbd11dc1e13805e07b8f995810e3766c', 'duyet2000@gmail.com', 1, 1),
(18, '7ece924f090ce5e0f6f9dd1c6d8e554c', 'duyet2000@gmail.com', 1, 1),
(19, 'b0530015517b1fded852a3807b0077a6', 'yplitgroup@gmail.com', 1, 0);

DROP TABLE IF EXISTS `yp_module_news`;
CREATE TABLE `yp_module_news` (
  `post_id` int(10) NOT NULL AUTO_INCREMENT,
  `cat_id` int(10) NOT NULL DEFAULT '0',
  `title` varchar(150) NOT NULL,
  `post` text NOT NULL,
  `keywork` varchar(250) NOT NULL,
  `reply_count` int(10) NOT NULL DEFAULT '0',
  `view_count` int(10) NOT NULL DEFAULT '0',
  `user_id` int(10) NOT NULL DEFAULT '0',
  `username` varchar(50) NOT NULL,
  `post_date` int(10) NOT NULL,
  `like` varchar(250) NOT NULL,
  `like_count` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`post_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `yp_module_news` VALUES
(1, 1, 'Ra mắt chính thức ypCore CMS v1.0', '\n \nChính thức ra mắt ypCore ampha v1.0 &lt;br /&gt; \n&lt;br /&gt;\nSau 2 tháng Code cuối cùng bản Final cũng đã hoàn thành!&lt;br /&gt;\n \n', '', 0, 148, 1, 'admin', 1374554396, '', 5),
(4, 1, 'Chính thức ra mắt bản Open Beta ypCore v1.3', '&lt;p&gt;&lt;em&gt;25/07/2013&lt;/em&gt; - Lemon9x.com&lt;/p&gt;\r\n\r\n&lt;p&gt;Chính thức ra mắt bản &lt;small&gt;Open Beta ypCore v1.2&lt;/small&gt;. Sau nhiều ngày code, đội code đã hoàn thành bản beta.&lt;/p&gt;\r\n\r\n&lt;p&gt;Trong lần ra mắt này, ypCore đã fix nhiều lỗi, cải thiện load trang. Framework mạnh mẽ.Cụ thể&lt;/p&gt;\r\n\r\n&lt;ol&gt;\r\n	&lt;li&gt;Dựng lại bộ loader&lt;/li&gt;\r\n	&lt;li&gt;Fix css trên IE&lt;/li&gt;\r\n	&lt;li&gt;Update module News&lt;/li&gt;\r\n	&lt;li&gt;Update Admin Module&lt;/li&gt;\r\n	&lt;li&gt;Update Module News&lt;/li&gt;\r\n	&lt;li&gt;Thêm chức năng quản lý file upload&lt;/li&gt;\r\n&lt;/ol&gt;\r\n\r\n&lt;p&gt;Mọi thắc mắc hoặc bug lỗi vui lòng liên hệ &lt;a href=&quot;http://lemon9x.com/ypCore/index.php?code=Contact&quot; target=&quot;_blank&quot;&gt;tại đây&lt;/a&gt; hoặc email: &lt;em&gt;duyet2000@gmail.com.&lt;/em&gt;&lt;/p&gt;\r\n\r\n&lt;hr /&gt;\r\n&lt;p style=&quot;margin-left: 800px; &quot;&gt;Coder Team&lt;/p&gt;\r\n', 'ypcore, google.$%^#$^%#$%', 0, 9, 0, 'admin', 1374737849, '', 0),
(5, 1, 'Chính thức ra mắt bản Open Beta ypCore v1.1', '&lt;p style=&quot;margin-top: 0px; margin-right: 0px; margin-bottom: 12.5px; margin-left: 0px; &quot;&gt;&lt;em style=&quot;font-style: italic; &quot;&gt;25/07/2013&lt;/em&gt;&amp;nbsp;- Lemon9x.com&lt;/p&gt;\r\n\r\n&lt;p style=&quot;margin-top: 0px; margin-right: 0px; margin-bottom: 12.5px; margin-left: 0px; &quot;&gt;Chính thức ra mắt bản&amp;nbsp;&lt;small style=&quot;font-size: 12px; &quot;&gt;Open Beta ypCore v1.2&lt;/small&gt;. Sau nhiều ngày code, đội code đã hoàn thành bản beta.&lt;/p&gt;\r\n\r\n&lt;p style=&quot;margin-top: 0px; margin-right: 0px; margin-bottom: 12.5px; margin-left: 0px; &quot;&gt;Trong lần ra mắt này, ypCore đã fix nhiều lỗi, cải thiện load trang. Framework mạnh mẽ.Cụ thể&lt;/p&gt;\r\n\r\n&lt;ol style=&quot;padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; margin-top: 0px; margin-right: 0px; margin-bottom: 12.5px; margin-left: 25px; &quot;&gt;\r\n	&lt;li style=&quot;line-height: 25px; display: list-item; margin-bottom: 7px; &quot;&gt;Dựng lại bộ loader&lt;/li&gt;\r\n	&lt;li style=&quot;line-height: 25px; display: list-item; margin-bottom: 7px; &quot;&gt;Fix css trên IE&lt;/li&gt;\r\n	&lt;li style=&quot;line-height: 25px; display: list-item; margin-bottom: 7px; &quot;&gt;Update module News&lt;/li&gt;\r\n	&lt;li style=&quot;line-height: 25px; display: list-item; margin-bottom: 7px; &quot;&gt;Update Admin Module&lt;/li&gt;\r\n	&lt;li style=&quot;line-height: 25px; display: list-item; margin-bottom: 7px; &quot;&gt;Update Module News&lt;/li&gt;\r\n	&lt;li style=&quot;line-height: 25px; display: list-item; margin-bottom: 7px; &quot;&gt;Thêm chức năng quản lý file upload&lt;/li&gt;\r\n&lt;/ol&gt;\r\n\r\n&lt;p style=&quot;margin-top: 0px; margin-right: 0px; margin-bottom: 12.5px; margin-left: 0px; &quot;&gt;Mọi thắc mắc hoặc bug lỗi vui lòng liên hệ&amp;nbsp;&lt;a href=&quot;http://lemon9x.com/ypCore/index.php?code=Contact&quot; style=&quot;color: rgb(51, 153, 204); text-decoration: none; &quot; target=&quot;_blank&quot;&gt;tại đây&lt;/a&gt;&amp;nbsp;hoặc email:&amp;nbsp;&lt;em style=&quot;font-style: italic; &quot;&gt;duyet2000@gmail.com.&lt;/em&gt;&lt;/p&gt;\r\n', 'thông báo, ypcore', 0, 6, 0, 'admin', 1374747735, '', 0);

DROP TABLE IF EXISTS `yp_module_news_cat`;
CREATE TABLE `yp_module_news_cat` (
  `cat_id` int(10) NOT NULL AUTO_INCREMENT,
  `title` varchar(150) NOT NULL,
  `description` varchar(250) NOT NULL,
  `cat_parent_id` int(10) NOT NULL DEFAULT '0',
  `order` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`cat_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `yp_module_news_cat` VALUES
(1, 'Thông báo', 'Thông báo, tin tức mới', 0, 1),
(2, 'Tin tức', 'Tin tức, tin giới trẻ, tin thế giới...', 0, 0),
(3, 'Hệ thống', 'Thông báo mới từ hệ thống', 1, 0),
(4, 'Đội code', 'Thông tin từ đội code', 1, 0);

DROP TABLE IF EXISTS `yp_module_news_comment`;
CREATE TABLE `yp_module_news_comment` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `post_id` int(10) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  `username` varchar(150) NOT NULL,
  `comment` text NOT NULL,
  `date` int(10) NOT NULL,
  `like` text NOT NULL,
  `like_count` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `yp_module_news_comment` VALUES
(1, 1, 1, 'admin', 'Tuyệt! Phải test thử mới được!', 0, '', 0),
(2, 1, 1, 'MOD', 'Good Job!', 0, '', 0);

DROP TABLE IF EXISTS `yp_module_news_setting`;
CREATE TABLE `yp_module_news_setting` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `var` varchar(50) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `yp_module_news_setting` VALUES
(1, 'show_view_counter', '1'),
(2, 'like_active', '1');

DROP TABLE IF EXISTS `yp_module_news_tag`;
CREATE TABLE `yp_module_news_tag` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tag` varchar(250) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `yp_module_news_tag` VALUES
(1, 'thông báo'),
(2, '');

DROP TABLE IF EXISTS `yp_settings`;
CREATE TABLE `yp_settings` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `value` text NOT NULL,
  `serialized` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `yp_settings` VALUES
(1, 'site_name', 'ypCore v1.0', 0),
(2, 'site_description', 'ypCore', 0),
(3, 'rewrite', '0', 0),
(4, 'template', 'default', 0),
(5, 'language', 'en', 0),
(6, 'firewall', '1', 0),
(7, 'debug', '0', 0),
(8, 'tmp', '/tmp', 0),
(9, 'download_path', 'source/d.png', 0),
(10, 'default_module', 'News/Index', 0),
(11, 'google_analytics_code', 'UX-xxxxxxx', 0),
(12, 'admin_language', 'en', 0),
(13, 'site_keywork', 'ypcore, news', 0),
(14, 'compress_page', '0', 0),
(15, 'addthis', '1', 0),
(16, 'template_list', 'a:1:{i:0;s:7:\"default\";}', 1),
(17, 'cache', '1', 0),
(18, 'upload_dir', '/apps/upload', 0),
(19, 'register_active', '1', 0);

DROP TABLE IF EXISTS `yp_usergroup`;
CREATE TABLE `yp_usergroup` (
  `groupid` int(11) NOT NULL AUTO_INCREMENT,
  `groupname` varchar(20) NOT NULL,
  `description` varchar(200) NOT NULL,
  PRIMARY KEY (`groupid`)
) ENGINE=InnoDB AUTO_INCREMENT=5 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `yp_usergroup` VALUES
(1, 'Member', ''),
(2, 'Moderation', ''),
(3, 'Supper Moderation', ''),
(4, 'Administrator', '');

DROP TABLE IF EXISTS `yp_users`;
CREATE TABLE `yp_users` (
  `userid` int(11) NOT NULL AUTO_INCREMENT,
  `username` text NOT NULL,
  `password` text NOT NULL,
  `salt` varchar(10) NOT NULL,
  `full_name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `groupid` tinyint(2) NOT NULL DEFAULT '1',
  `birthday` date NOT NULL,
  `register_day` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`userid`)
) ENGINE=InnoDB AUTO_INCREMENT=6 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `yp_users` VALUES
(5, 'admin', 'de9efea127212e7a9abadf6b717eeb56', '7389AEEA88', '', 'duyet2000@gmail.com', 4, '0000-00-00', '2013-07-21 08:27:56');

