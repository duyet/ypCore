#SKD101|ypCore|7|2014.02.01 15:08:27|93|4|14|5|62|4|4

DROP TABLE IF EXISTS `yp_module_news`;
CREATE TABLE `yp_module_news` (
  `post_id` int(10) NOT NULL AUTO_INCREMENT,
  `title` varchar(250) NOT NULL,
  `title_alias` varchar(250) NOT NULL,
  `post` text NOT NULL,
  `tag` varchar(250) NOT NULL,
  `keyword` varchar(250) NOT NULL,
  `reply_count` int(10) NOT NULL DEFAULT '0',
  `view_count` int(10) NOT NULL DEFAULT '0',
  `user_id` int(10) NOT NULL DEFAULT '0',
  `username` varchar(50) NOT NULL,
  `post_date` int(10) NOT NULL,
  `like` varchar(250) NOT NULL,
  `like_count` int(10) NOT NULL DEFAULT '0',
  `status` varchar(10) NOT NULL DEFAULT '1',
  `time_last_change` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`post_id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `yp_module_news_cat`;
CREATE TABLE `yp_module_news_cat` (
  `cat_id` int(10) NOT NULL AUTO_INCREMENT,
  `title` varchar(250) NOT NULL,
  `title_alias` varchar(250) NOT NULL,
  `description` varchar(250) NOT NULL,
  `cat_parent_id` int(10) NOT NULL DEFAULT '0',
  `order` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`cat_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `yp_module_news_cat` VALUES