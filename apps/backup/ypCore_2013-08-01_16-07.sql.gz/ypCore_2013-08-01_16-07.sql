#SKD101|ypCore|11|2013.08.01 16:07:18|90|4|1|10|3|4|13|13|5|30|4|3

DROP TABLE IF EXISTS `yp_download_email_list`;
CREATE TABLE `yp_download_email_list` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `email` varchar(100) NOT NULL,
  `download` int(10) NOT NULL DEFAULT '1',
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `yp_download_email_list` VALUES
(1, 'duyet2000@gmail.com', 24, '2013-07-22 08:12:31'),
(2, 'yplitgroup@gmail.com', 4, '2013-07-22 08:21:13'),
(3, 'chibisan.net@gmail.com', 1, '2013-07-22 08:21:29'),
(4, 'yplitgroup@facebook.com', 1, '2013-07-22 08:21:42');

DROP TABLE IF EXISTS `yp_download_files`;
CREATE TABLE `yp_download_files` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `path` varchar(250) NOT NULL,
  `download` int(250) NOT NULL DEFAULT '1',
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `yp_download_files` VALUES
(1, 'source/ypCore.zip', 11, '2013-07-22 08:41:50');

DROP TABLE IF EXISTS `yp_download_list_waiting`;
CREATE TABLE `yp_download_list_waiting` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `code` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `file_id` int(50) NOT NULL,
  `active` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `yp_download_list_waiting` VALUES
(10, '91b60365dd3413189eca9f081b91fd8d', '', 1, 0),
(11, '5fcdcd24a97cf4dd04b670f46a91dc49', '', 1, 0),
(12, '3bf2ddf87f1d467105da047e3f092f1c', '', 1, 0),
(13, 'fda154462add355fdf97d8c841eb844b', '', 1, 0),
(14, '9614991dc8aaea35b155b82179a1c3b2', 'duyet2000@gmail.com', 1, 0),
(15, 'c70dc6e1ba239ec4422857908cdd3b6f', 'duyet2000@gmail.com', 1, 0),
(16, 'fc28ec2c917ae86325b78e1003cc35d3', 'duyet2000@gmail.com', 1, 0),
(17, 'dbd11dc1e13805e07b8f995810e3766c', 'duyet2000@gmail.com', 1, 1),
(18, '7ece924f090ce5e0f6f9dd1c6d8e554c', 'duyet2000@gmail.com', 1, 1),
(19, 'b0530015517b1fded852a3807b0077a6', 'yplitgroup@gmail.com', 1, 0);

DROP TABLE IF EXISTS `yp_module_news`;
CREATE TABLE `yp_module_news` (
  `post_id` int(10) NOT NULL AUTO_INCREMENT,
  `cat_id` int(10) NOT NULL DEFAULT '0',
  `title` varchar(150) NOT NULL,
  `post` text NOT NULL,
  `keywork` varchar(250) NOT NULL,
  `reply_count` int(10) NOT NULL DEFAULT '0',
  `view_count` int(10) NOT NULL DEFAULT '0',
  `user_id` int(10) NOT NULL DEFAULT '0',
  `username` varchar(50) NOT NULL,
  `post_date` int(10) NOT NULL,
  `like` varchar(250) NOT NULL,
  `like_count` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`post_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `yp_module_news` VALUES
(1, 1, 'Ra mắt chính thức ypCore CMS v1.0', '\n \nChính thức ra mắt ypCore ampha v1.0 &lt;br /&gt; \n&lt;br /&gt;\nSau 2 tháng Code cuối cùng bản Final cũng đã hoàn thành!&lt;br /&gt;\n \n', '', 0, 212, 1, 'admin', 1374554396, '', 5),
(5, 1, 'Chính thức ra mắt bản Open Beta ypCore v1.1', '&lt;p style=&quot;margin-top: 0px; margin-right: 0px; margin-bottom: 12.5px; margin-left: 0px; &quot;&gt;&lt;em style=&quot;font-style: italic; &quot;&gt;25/07/2013&lt;/em&gt;&amp;nbsp;- Lemon9x.com&lt;/p&gt;\r\n\r\n&lt;p style=&quot;margin-top: 0px; margin-right: 0px; margin-bottom: 12.5px; margin-left: 0px; &quot;&gt;Chính thức ra mắt bản&amp;nbsp;&lt;small style=&quot;font-size: 12px; &quot;&gt;Open Beta ypCore v1.2&lt;/small&gt;. Sau nhiều ngày code, đội code đã hoàn thành bản beta.&lt;/p&gt;\r\n\r\n&lt;p style=&quot;margin-top: 0px; margin-right: 0px; margin-bottom: 12.5px; margin-left: 0px; &quot;&gt;Trong lần ra mắt này, ypCore đã fix nhiều lỗi, cải thiện load trang. Framework mạnh mẽ.Cụ thể&lt;/p&gt;\r\n\r\n&lt;ol style=&quot;padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; margin-top: 0px; margin-right: 0px; margin-bottom: 12.5px; margin-left: 25px; &quot;&gt;\r\n	&lt;li style=&quot;line-height: 25px; display: list-item; margin-bottom: 7px; &quot;&gt;Dựng lại bộ loader&lt;/li&gt;\r\n	&lt;li style=&quot;line-height: 25px; display: list-item; margin-bottom: 7px; &quot;&gt;Fix css trên IE&lt;/li&gt;\r\n	&lt;li style=&quot;line-height: 25px; display: list-item; margin-bottom: 7px; &quot;&gt;Update module News&lt;/li&gt;\r\n	&lt;li style=&quot;line-height: 25px; display: list-item; margin-bottom: 7px; &quot;&gt;Update Admin Module&lt;/li&gt;\r\n	&lt;li style=&quot;line-height: 25px; display: list-item; margin-bottom: 7px; &quot;&gt;Update Module News&lt;/li&gt;\r\n	&lt;li style=&quot;line-height: 25px; display: list-item; margin-bottom: 7px; &quot;&gt;Thêm chức năng quản lý file upload&lt;/li&gt;\r\n&lt;/ol&gt;\r\n\r\n&lt;p style=&quot;margin-top: 0px; margin-right: 0px; margin-bottom: 12.5px; margin-left: 0px; &quot;&gt;Mọi thắc mắc hoặc bug lỗi vui lòng liên hệ&amp;nbsp;&lt;a href=&quot;http://lemon9x.com/ypCore/index.php?code=Contact&quot; style=&quot;color: rgb(51, 153, 204); text-decoration: none; &quot; target=&quot;_blank&quot;&gt;tại đây&lt;/a&gt;&amp;nbsp;hoặc email:&amp;nbsp;&lt;em style=&quot;font-style: italic; &quot;&gt;duyet2000@gmail.com.&lt;/em&gt;&lt;/p&gt;\r\n', 'thông báo, ypcore', 0, 248, 0, 'admin', 1374747735, '', 0),
(6, 2, 'Những câu hỏi phỏng vấn ', '&lt;div class=&quot;summary clearfix&quot; style=&quot;margin-top: 0px; margin-right: 0px; margin-bottom: 5px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 5px; padding-left: 0px; border-top-width: 0px; border-right-width: 0px; border-bottom-width: 1px; border-left-width: 0px; border-style: initial; border-color: initial; font-weight: bold; font-style: inherit; font-size: 12px !important; font-family: Arial !important; vertical-align: baseline; display: block; border-bottom-style: solid; border-bottom-color: rgb(204, 204, 204); &quot;&gt;Bộ c&amp;acirc;u hỏi phỏng vấn v&amp;agrave;o Apple kh&amp;ocirc;ng hề kh&amp;oacute; trả lời, nhưng việc trả lời ch&amp;uacute;ng ra sao để nh&amp;agrave; tuyển dụng h&amp;agrave;i l&amp;ograve;ng lại l&amp;agrave; điều ho&amp;agrave;n to&amp;agrave;n kh&amp;aacute;c.&lt;/div&gt;\r\n\r\n&lt;div class=&quot;content clearfix&quot; style=&quot;margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; border-top-width: 0px; border-right-width: 0px; border-bottom-width: 0px; border-left-width: 0px; border-style: initial; border-color: initial; font-weight: inherit; font-style: inherit; font-size: 12px !important; font-family: Arial !important; vertical-align: baseline; display: block; &quot;&gt;\r\n&lt;div style=&quot;margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; border-top-width: 0px; border-right-width: 0px; border-bottom-width: 0px; border-left-width: 0px; border-style: initial; border-color: initial; font-weight: inherit; font-style: inherit; font-size: 12px !important; font-family: Arial !important; vertical-align: baseline; &quot;&gt;Để c&amp;oacute; được c&amp;ocirc;ng việc tại c&amp;aacute;c c&amp;ocirc;ng ty c&amp;ocirc;ng nghệ lớn tr&amp;ecirc;n thế giới l&amp;agrave; điều kh&amp;ocirc;ng hề dễ d&amp;agrave;ng, ngo&amp;agrave;i kiến thức vượt trội về lĩnh vực được học, bạn c&amp;ograve;n phải c&amp;oacute; rất nhiều kĩ năng kh&amp;aacute;c để đ&amp;aacute;p ứng được những nhu cầu h&amp;agrave;ng ng&amp;agrave;y của c&amp;ocirc;ng ty. Từ Google, Microsoft, Facebook hay thậm ch&amp;iacute; l&amp;agrave; cả Apple, c&amp;aacute;c ứng cử vi&amp;ecirc;n đều phải trải qua một v&amp;ograve;ng phỏng vấn với c&amp;aacute;c c&amp;acirc;u hỏi rất kh&amp;oacute; khăn. Nếu như ở Google v&amp;agrave; Facebook, c&amp;aacute;c c&amp;acirc;u hỏi n&amp;agrave;y l&amp;agrave;m cho người d&amp;ugrave;ng phải vắt n&amp;atilde;o suy nghĩ th&amp;igrave; tại Apple, những c&amp;acirc;u hỏi phỏng vấn kh&amp;ocirc;ng phải qu&amp;aacute; kh&amp;oacute; để trả lời, vấn đề ch&amp;iacute;nh ở đ&amp;acirc;y l&amp;agrave; trả lời sao cho hợp l&amp;yacute;.&lt;/div&gt;\r\n&lt;/div&gt;\r\n\r\n&lt;div style=&quot;margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; border-top-width: 0px; border-right-width: 0px; border-bottom-width: 0px; border-left-width: 0px; border-style: initial; border-color: initial; font-weight: inherit; font-style: inherit; font-size: 12px !important; font-family: Arial !important; vertical-align: baseline; text-align: center; &quot;&gt;&lt;img a=&quot;&quot; alt=&quot;Những câu hỏi phỏng vấn &quot; apple=&quot;&quot; c=&quot;&quot; h=&quot;683&quot; id=&quot;Những câu hỏi phỏng vấn &quot; lb=&quot;1&quot; src=&quot;http://k14.vcmedia.vn/k:thumb_w/600/994cDL3cmLDsEtiKLBokEWLgcC5xLI/Image/2013/07/07a/130727tekapple1-f2ca8/nhung-cau-hoi-phong-van-cuc-khoai-cua-apple.jpg&quot; style=&quot;border-bottom-width:0px; border-color:initial; border-left-width:0px; border-right-width:0px; border-style:initial; border-top-width:0px; font-family:inherit; font-size:12px; font-style:inherit; font-weight:inherit; margin-bottom:0px; margin-left:0px; margin-right:0px; margin-top:0px; padding-bottom:0px; padding-left:0px; padding-right:0px; padding-top:0px; vertical-align:baseline&quot; title=&quot;Những câu hỏi phỏng vấn &quot; w=&quot;1024&quot; /&gt;&lt;/div&gt;\r\n\r\n&lt;div style=&quot;margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; border-top-width: 0px; border-right-width: 0px; border-bottom-width: 0px; border-left-width: 0px; border-style: initial; border-color: initial; font-weight: inherit; font-style: inherit; font-size: 12px !important; font-family: Arial !important; vertical-align: baseline; text-align: center; &quot;&gt;&lt;em&gt;M&amp;ocirc;i trường l&amp;agrave;m việc hiện đại của Apple y&amp;ecirc;u cầu những nh&amp;acirc;n vi&amp;ecirc;n l&amp;agrave;m việc tại đ&amp;acirc;y cũng phải hết sức hiện đại&lt;/em&gt;&lt;/div&gt;\r\n\r\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;\r\n\r\n&lt;div class=&quot;content clearfix&quot; style=&quot;margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; border-top-width: 0px; border-right-width: 0px; border-bottom-width: 0px; border-left-width: 0px; border-style: initial; border-color: initial; font-weight: inherit; font-style: inherit; font-size: 12px !important; font-family: Arial !important; vertical-align: baseline; display: block; &quot;&gt;\r\n&lt;div style=&quot;margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; border-top-width: 0px; border-right-width: 0px; border-bottom-width: 0px; border-left-width: 0px; border-style: initial; border-color: initial; font-weight: inherit; font-style: inherit; font-size: 12px !important; font-family: Arial !important; vertical-align: baseline; &quot;&gt;Tổ chức Glassdoor mới đ&amp;acirc;y đ&amp;atilde; tổng hợp lại những c&amp;acirc;u hỏi phỏng vấn &amp;quot;khoai&amp;quot; nhất từ trước tới giờ của Apple. H&amp;atilde;y tự xem m&amp;igrave;nh trả lời được bao nhi&amp;ecirc;u trong số những c&amp;acirc;u hỏi n&amp;agrave;y nh&amp;eacute;!&lt;/div&gt;\r\n\r\n&lt;div style=&quot;margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; border-top-width: 0px; border-right-width: 0px; border-bottom-width: 0px; border-left-width: 0px; border-style: initial; border-color: initial; font-weight: inherit; font-style: inherit; font-size: 12px !important; font-family: Arial !important; vertical-align: baseline; &quot;&gt;&amp;nbsp;&lt;/div&gt;\r\n\r\n&lt;div style=&quot;margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; border-top-width: 0px; border-right-width: 0px; border-bottom-width: 0px; border-left-width: 0px; border-style: initial; border-color: initial; font-weight: inherit; font-style: inherit; font-size: 12px !important; font-family: Arial !important; vertical-align: baseline; &quot;&gt;1. Điều g&amp;igrave; bạn từng l&amp;agrave;m khiến bạn cảm thấy tự h&amp;agrave;o nhất? - Vị tr&amp;iacute; gi&amp;aacute;m đốc ph&amp;aacute;t triển phần mềm.&lt;/div&gt;\r\n\r\n&lt;div style=&quot;margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; border-top-width: 0px; border-right-width: 0px; border-bottom-width: 0px; border-left-width: 0px; border-style: initial; border-color: initial; font-weight: inherit; font-style: inherit; font-size: 12px !important; font-family: Arial !important; vertical-align: baseline; &quot;&gt;&amp;nbsp;&lt;/div&gt;\r\n\r\n&lt;div style=&quot;margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; border-top-width: 0px; border-right-width: 0px; border-bottom-width: 0px; border-left-width: 0px; border-style: initial; border-color: initial; font-weight: inherit; font-style: inherit; font-size: 12px !important; font-family: Arial !important; vertical-align: baseline; &quot;&gt;2. Từ những thất bại đ&amp;atilde; c&amp;oacute;, đ&amp;acirc;u l&amp;agrave; b&amp;agrave;i học lớn nhất của bạn? - Vị tr&amp;iacute; gi&amp;aacute;m đốc phần mềm.&lt;/div&gt;\r\n\r\n&lt;div style=&quot;margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; border-top-width: 0px; border-right-width: 0px; border-bottom-width: 0px; border-left-width: 0px; border-style: initial; border-color: initial; font-weight: inherit; font-style: inherit; font-size: 12px !important; font-family: Arial !important; vertical-align: baseline; &quot;&gt;&amp;nbsp;&lt;/div&gt;\r\n\r\n&lt;div style=&quot;margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; border-top-width: 0px; border-right-width: 0px; border-bottom-width: 0px; border-left-width: 0px; border-style: initial; border-color: initial; font-weight: inherit; font-style: inherit; font-size: 12px !important; font-family: Arial !important; vertical-align: baseline; &quot;&gt;3. H&amp;atilde;y m&amp;ocirc; tả một vấn đề rất th&amp;uacute; vị bạn từng gặp phải đồng thời l&amp;agrave; c&amp;aacute;ch thức bạn giải quyết vấn đề đ&amp;oacute;? - Vị tr&amp;iacute; kĩ sư phần mềm.&lt;/div&gt;\r\n\r\n&lt;div style=&quot;margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; border-top-width: 0px; border-right-width: 0px; border-bottom-width: 0px; border-left-width: 0px; border-style: initial; border-color: initial; font-weight: inherit; font-style: inherit; font-size: 12px !important; font-family: Arial !important; vertical-align: baseline; &quot;&gt;&amp;nbsp;&lt;/div&gt;\r\n\r\n&lt;div style=&quot;margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; border-top-width: 0px; border-right-width: 0px; border-bottom-width: 0px; border-left-width: 0px; border-style: initial; border-color: initial; font-weight: inherit; font-style: inherit; font-size: 12px !important; font-family: Arial !important; vertical-align: baseline; &quot;&gt;4. H&amp;atilde;y giải th&amp;iacute;ch về modem để một đứa trẻ 8 tuổi c&amp;oacute; thể hiểu được? - Vị tr&amp;iacute; tư vấn vi&amp;ecirc;n.&lt;/div&gt;\r\n\r\n&lt;div style=&quot;margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; border-top-width: 0px; border-right-width: 0px; border-bottom-width: 0px; border-left-width: 0px; border-style: initial; border-color: initial; font-weight: inherit; font-style: inherit; font-size: 12px !important; font-family: Arial !important; vertical-align: baseline; &quot;&gt;&amp;nbsp;&lt;/div&gt;\r\n\r\n&lt;div style=&quot;margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; border-top-width: 0px; border-right-width: 0px; border-bottom-width: 0px; border-left-width: 0px; border-style: initial; border-color: initial; font-weight: inherit; font-style: inherit; font-size: 12px !important; font-family: Arial !important; vertical-align: baseline; &quot;&gt;5. Điều g&amp;igrave; đ&amp;atilde; l&amp;agrave;m bạn đến phỏng vấn tại Apple? - Vị tr&amp;iacute; kĩ sư phần mềm.&lt;/div&gt;\r\n\r\n&lt;div style=&quot;margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; border-top-width: 0px; border-right-width: 0px; border-bottom-width: 0px; border-left-width: 0px; border-style: initial; border-color: initial; font-weight: inherit; font-style: inherit; font-size: 12px !important; font-family: Arial !important; vertical-align: baseline; &quot;&gt;&amp;nbsp;&lt;/div&gt;\r\n\r\n&lt;div style=&quot;margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; border-top-width: 0px; border-right-width: 0px; border-bottom-width: 0px; border-left-width: 0px; border-style: initial; border-color: initial; font-weight: inherit; font-style: inherit; font-size: 12px !important; font-family: Arial !important; vertical-align: baseline; &quot;&gt;\r\n&lt;div style=&quot;margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; border-top-width: 0px; border-right-width: 0px; border-bottom-width: 0px; border-left-width: 0px; border-style: initial; border-color: initial; font-weight: inherit; font-style: inherit; font-size: 12px !important; font-family: Arial !important; vertical-align: baseline; text-align: center; &quot;&gt;&lt;img a=&quot;&quot; alt=&quot;Những câu hỏi phỏng vấn &quot; apple=&quot;&quot; c=&quot;&quot; lb=&quot;2&quot; src=&quot;http://k14.vcmedia.vn/k:994cDL3cmLDsEtiKLBokEWLgcC5xLI/Image/2013/07/07a/130727tekapple2-f2ca8/nhung-cau-hoi-phong-van-cuc-khoai-cua-apple.jpg&quot; style=&quot;border-bottom-width:0px; border-color:initial; border-left-width:0px; border-right-width:0px; border-style:initial; border-top-width:0px; font-family:inherit; font-size:12px; font-style:inherit; font-weight:inherit; margin-bottom:0px; margin-left:0px; margin-right:0px; margin-top:0px; padding-bottom:0px; padding-left:0px; padding-right:0px; padding-top:0px; vertical-align:baseline&quot; title=&quot;Những câu hỏi phỏng vấn &quot; /&gt;&lt;/div&gt;\r\n\r\n&lt;div style=&quot;margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; border-top-width: 0px; border-right-width: 0px; border-bottom-width: 0px; border-left-width: 0px; border-style: initial; border-color: initial; font-weight: inherit; font-style: inherit; font-size: 12px !important; font-family: Arial !important; vertical-align: baseline; text-align: center; &quot;&gt;&lt;em&gt;Một b&amp;agrave;n l&amp;agrave;m việc tại trụ sở Apple.&lt;/em&gt;&lt;/div&gt;\r\n&lt;/div&gt;\r\n\r\n&lt;div style=&quot;margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; border-top-width: 0px; border-right-width: 0px; border-bottom-width: 0px; border-left-width: 0px; border-style: initial; border-color: initial; font-weight: inherit; font-style: inherit; font-size: 12px !important; font-family: Arial !important; vertical-align: baseline; &quot;&gt;6. Bạn muốn l&amp;agrave;m g&amp;igrave; trong 5 năm tiếp theo? - Vị tr&amp;iacute; kĩ sư phần mềm.&lt;/div&gt;\r\n\r\n&lt;div style=&quot;margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; border-top-width: 0px; border-right-width: 0px; border-bottom-width: 0px; border-left-width: 0px; border-style: initial; border-color: initial; font-weight: inherit; font-style: inherit; font-size: 12px !important; font-family: Arial !important; vertical-align: baseline; &quot;&gt;&amp;nbsp;&lt;/div&gt;\r\n\r\n&lt;div style=&quot;margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; border-top-width: 0px; border-right-width: 0px; border-bottom-width: 0px; border-left-width: 0px; border-style: initial; border-color: initial; font-weight: inherit; font-style: inherit; font-size: 12px !important; font-family: Arial !important; vertical-align: baseline; &quot;&gt;7. Tại sao bạn muốn gia nhập Apple? L&amp;agrave;m việc tại Apple khiến bạn mất đi những g&amp;igrave; so với c&amp;ocirc;ng việc hiện tại? - Vị tr&amp;iacute; kĩ sư phần mềm.&lt;/div&gt;\r\n\r\n&lt;div style=&quot;margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; border-top-width: 0px; border-right-width: 0px; border-bottom-width: 0px; border-left-width: 0px; border-style: initial; border-color: initial; font-weight: inherit; font-style: inherit; font-size: 12px !important; font-family: Arial !important; vertical-align: baseline; &quot;&gt;&amp;nbsp;&lt;/div&gt;\r\n\r\n&lt;div style=&quot;margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; border-top-width: 0px; border-right-width: 0px; border-bottom-width: 0px; border-left-width: 0px; border-style: initial; border-color: initial; font-weight: inherit; font-style: inherit; font-size: 12px !important; font-family: Arial !important; vertical-align: baseline; &quot;&gt;8. L&amp;agrave;m c&amp;aacute;ch n&amp;agrave;o để kiểm tra một chiếc m&amp;aacute;y nướng b&amp;aacute;nh m&amp;igrave;? - Vị tr&amp;iacute; kĩ sư phần mềm.&lt;/div&gt;\r\n\r\n&lt;div style=&quot;margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; border-top-width: 0px; border-right-width: 0px; border-bottom-width: 0px; border-left-width: 0px; border-style: initial; border-color: initial; font-weight: inherit; font-style: inherit; font-size: 12px !important; font-family: Arial !important; vertical-align: baseline; &quot;&gt;&amp;nbsp;&lt;/div&gt;\r\n\r\n&lt;div style=&quot;margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; border-top-width: 0px; border-right-width: 0px; border-bottom-width: 0px; border-left-width: 0px; border-style: initial; border-color: initial; font-weight: inherit; font-style: inherit; font-size: 12px !important; font-family: Arial !important; vertical-align: baseline; &quot;&gt;9. Nếu như được Apple thu&amp;ecirc;, bạn muốn l&amp;agrave;m g&amp;igrave;? - Vị tr&amp;iacute; CTV ph&amp;aacute;t triển phần mềm.&lt;/div&gt;\r\n\r\n&lt;div style=&quot;margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; border-top-width: 0px; border-right-width: 0px; border-bottom-width: 0px; border-left-width: 0px; border-style: initial; border-color: initial; font-weight: inherit; font-style: inherit; font-size: 12px !important; font-family: Arial !important; vertical-align: baseline; &quot;&gt;&amp;nbsp;&lt;/div&gt;\r\n\r\n&lt;div style=&quot;margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; border-top-width: 0px; border-right-width: 0px; border-bottom-width: 0px; border-left-width: 0px; border-style: initial; border-color: initial; font-weight: inherit; font-style: inherit; font-size: 12px !important; font-family: Arial !important; vertical-align: baseline; &quot;&gt;10. Tại sao ch&amp;uacute;ng t&amp;ocirc;i n&amp;ecirc;n tuyển bạn? - Vị tr&amp;iacute; CTV ph&amp;aacute;t triển phần mềm.&lt;/div&gt;\r\n\r\n&lt;div style=&quot;margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; border-top-width: 0px; border-right-width: 0px; border-bottom-width: 0px; border-left-width: 0px; border-style: initial; border-color: initial; font-weight: inherit; font-style: inherit; font-size: 12px !important; font-family: Arial !important; vertical-align: baseline; &quot;&gt;&amp;nbsp;&lt;/div&gt;\r\n\r\n&lt;div style=&quot;margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; border-top-width: 0px; border-right-width: 0px; border-bottom-width: 0px; border-left-width: 0px; border-style: initial; border-color: initial; font-weight: inherit; font-style: inherit; font-size: 12px !important; font-family: Arial !important; vertical-align: baseline; &quot;&gt;11. Bạn c&amp;oacute; s&amp;aacute;ng tạo kh&amp;ocirc;ng? H&amp;atilde;y thử kể một điều s&amp;aacute;ng tạo do bạn tự nghĩ ra? - Vị tr&amp;iacute; kĩ sư phần mềm.&lt;/div&gt;\r\n\r\n&lt;div style=&quot;margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; border-top-width: 0px; border-right-width: 0px; border-bottom-width: 0px; border-left-width: 0px; border-style: initial; border-color: initial; font-weight: inherit; font-style: inherit; font-size: 12px !important; font-family: Arial !important; vertical-align: baseline; &quot;&gt;&amp;nbsp;&lt;/div&gt;\r\n\r\n&lt;div style=&quot;margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; border-top-width: 0px; border-right-width: 0px; border-bottom-width: 0px; border-left-width: 0px; border-style: initial; border-color: initial; font-weight: inherit; font-style: inherit; font-size: 12px !important; font-family: Arial !important; vertical-align: baseline; &quot;&gt;Những c&amp;acirc;u hỏi của Apple kh&amp;ocirc;ng hề kh&amp;oacute;, kh&amp;ocirc;ng hề đỏi hỏi người được phỏng vấn phải vắt &amp;oacute;c suy nghĩ như việc c&amp;oacute; bao nhi&amp;ecirc;u ch&amp;uacute; b&amp;ograve; ở Canada hay những c&amp;acirc;u hỏi qu&amp;aacute; chuy&amp;ecirc;n s&amp;acirc;u về kĩ thuật như ở Microsoft. Tại Apple, họ lu&amp;ocirc;n muốn nh&amp;acirc;n vi&amp;ecirc;n của m&amp;igrave;nh tự đưa được quyết định đ&amp;uacute;ng đắn nhất, những quyết định m&amp;agrave; họ ho&amp;agrave;n to&amp;agrave;n phải tự chịu tr&amp;aacute;ch nhiệm về n&amp;oacute;.&lt;/div&gt;\r\n&lt;/div&gt;\r\n\r\n&lt;div style=&quot;margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; border-top-width: 0px; border-right-width: 0px; border-bottom-width: 0px; border-left-width: 0px; border-style: initial; border-color: initial; font-weight: inherit; font-style: inherit; font-size: 12px !important; font-family: Arial !important; vertical-align: baseline; clear: both; &quot;&gt;&amp;nbsp;&lt;/div&gt;\r\n\r\n&lt;div style=&quot;margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; border-top-width: 0px; border-right-width: 0px; border-bottom-width: 0px; border-left-width: 0px; border-style: initial; border-color: initial; font-weight: inherit; font-style: inherit; font-size: 12px !important; font-family: Arial !important; vertical-align: baseline; text-align: right; &quot;&gt;\r\n&lt;p style=&quot;margin-left:0px; margin-right:0px&quot;&gt;Nguồn: kenh14.vn&lt;/p&gt;\r\n&lt;/div&gt;\r\n', 'Những câu hỏi phỏng vấn ', 0, 78, 0, 'admin', 1374983958, '', 0),
(7, 2, 'Test CKeditor', '&lt;p dir=&quot;rtl&quot; style=&quot;text-align:center&quot;&gt;wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww&lt;/p&gt;\r\n\r\n&lt;div class=&quot;slideshowPlugin&quot; contenteditable=&quot;false&quot; data-animspeedid=&quot;500&quot; data-autostartid=&quot;true&quot; data-openonclickid=&quot;true&quot; data-pictheightid=&quot;300&quot; data-showcontrolid=&quot;true&quot; data-showthumbid=&quot;true&quot; data-showtitleid=&quot;true&quot; data-slideshowid=&quot;cke_3uzsjimg_slideShow&quot; data-speedid=&quot;5&quot; data-transitiontypeid=&quot;slide-hori&quot; id=&quot;cke_3uzsjimg_slideShow&quot;&gt;\r\n&lt;div class=&quot;ad-gallery&quot; contenteditable=&quot;false&quot; id=&quot;ad-gallery_cke_3uzsjimg_slideShow&quot;&gt;\r\n&lt;div class=&quot;ad-image-wrapper&quot; contenteditable=&quot;false&quot;&gt;&amp;nbsp;&lt;/div&gt;\r\n\r\n&lt;div class=&quot;ad-controls&quot; contenteditable=&quot;false&quot; style=&quot;display: block;&quot;&gt;&amp;nbsp;&lt;/div&gt;\r\n\r\n&lt;div class=&quot;ad-nav&quot; contenteditable=&quot;false&quot; style=&quot;display: block;&quot;&gt;\r\n&lt;div class=&quot;ad-thumbs&quot; contenteditable=&quot;false&quot;&gt;\r\n&lt;ul class=&quot;ad-thumb-list&quot; contenteditable=&quot;false&quot;&gt;\r\n	&lt;li contenteditable=&quot;false&quot;&gt;&lt;a href=&quot;http://localhost/ypCore/apps/download/image/hp_1.jpg&quot;&gt;&lt;img alt=&quot;&quot; contenteditable=&quot;false&quot; src=&quot;http://localhost/ypCore/apps/download/image/hp_1.jpg&quot; style=&quot;height:50px; width:50px&quot; title=&quot;&quot; /&gt;&lt;/a&gt;&lt;/li&gt;\r\n	&lt;li contenteditable=&quot;false&quot;&gt;&lt;a href=&quot;http://localhost/ypCore/apps/download/image/apple_logo.jpg&quot;&gt;&lt;img alt=&quot;&quot; contenteditable=&quot;false&quot; src=&quot;http://localhost/ypCore/apps/download/image/apple_logo.jpg&quot; style=&quot;height:50px; width:50px&quot; title=&quot;&quot; /&gt;&lt;/a&gt;&lt;/li&gt;\r\n	&lt;li contenteditable=&quot;false&quot;&gt;&lt;a href=&quot;http://localhost/ypCore/apps/download/image/canon_eos_5d_1.jpg&quot;&gt;&lt;img alt=&quot;&quot; contenteditable=&quot;false&quot; src=&quot;http://localhost/ypCore/apps/download/image/canon_eos_5d_1.jpg&quot; style=&quot;height:50px; width:50px&quot; title=&quot;&quot; /&gt;&lt;/a&gt;&lt;/li&gt;\r\n	&lt;li contenteditable=&quot;false&quot;&gt;&lt;a href=&quot;http://localhost/ypCore/apps/download/image/hp_logo.jpg&quot;&gt;&lt;img alt=&quot;&quot; contenteditable=&quot;false&quot; src=&quot;http://localhost/ypCore/apps/download/image/hp_logo.jpg&quot; style=&quot;height:50px; width:50px&quot; title=&quot;&quot; /&gt;&lt;/a&gt;&lt;/li&gt;\r\n&lt;/ul&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;script src=&quot;http://localhost/ypCore/apps/static//javascript/ckeditor/plugins/slideshow/3rdParty/ad-gallery/jquery.ad-gallery.min.js&quot; type=&quot;text/javascript&quot;&gt;&lt;/script&gt;&lt;script type=&quot;text/javascript&quot;&gt;$(\'head\').append(\'&lt;link rel=&quot;stylesheet&quot; href=&quot;http://localhost/ypCore/apps/static//javascript/ckeditor/plugins/slideshow/3rdParty/fancybox2/jquery.fancybox.css?v=2.1.5&quot; type=&quot;text/css&quot; /&gt;\');&lt;/script&gt;&lt;script src=&quot;http://localhost/ypCore/apps/static//javascript/ckeditor/plugins/slideshow/3rdParty/fancybox2/jquery.fancybox.pack.js?v=2.1.5&quot; type=&quot;text/javascript&quot;&gt;&lt;/script&gt;&lt;script type=&quot;text/javascript&quot;&gt;$(function() {$(&quot;#ad-gallery_cke_3uzsjimg_slideShow&quot;).on(&quot;click&quot;,&quot;.ad-image&quot;,function(){var imgObj =$(this).find(&quot;img&quot;);var isrc=imgObj.attr(&quot;src&quot;);var ititle=null;var idesc=null;var iname=isrc.split(\'/\');iname=iname[iname.length-1];var imgdescid=$(this).find(&quot;.ad-image-description&quot;);if(imgdescid){ititle=$(this).find(&quot;.ad-description-title&quot;);if(ititle)ititle=ititle.text();if(ititle!=\'\')ititle=\'&lt;big&gt;\'+ititle+\'&lt;/big&gt;\';idesc=$(this).find(&quot;span&quot;);if(idesc)idesc=idesc.text();if(idesc!=\'\'){if(ititle!=\'\')ititle=ititle+\'&lt;br&gt;\';idesc=\'&lt;i&gt;\'+idesc+\'&lt;/i&gt;\';}}$.fancybox.open({href:isrc,beforeLoad:function(){this.title=ititle+idesc;},});});});&lt;/script&gt;&lt;script type=&quot;text/javascript&quot;&gt;$(\'head\').append(\'&lt;link rel=&quot;stylesheet&quot; href=&quot;http://localhost/ypCore/apps/static//javascript/ckeditor/plugins/slideshow/3rdParty/ad-gallery/jquery.ad-gallery.css&quot; type=&quot;text/css&quot; /&gt;\');&lt;/script&gt;&lt;script type=&quot;text/javascript&quot;&gt;$(function() {   var galleries = $(\'#ad-gallery_cke_3uzsjimg_slideShow\').adGallery({loader_image: \'http://localhost/ypCore/apps/static//javascript/ckeditor/plugins/slideshow/3rdParty/ad-gallery/loader.gif\', width:false, height:300, start_at_index: 0, animation_speed: 500, update_window_hash: false, effect: \'slide-hori\', slideshow: { enable: true, autostart: true, speed: 5000,},});});&lt;/script&gt;&lt;/div&gt;\r\n\r\n&lt;p&gt;wewwwwwwwwwwww&lt;/p&gt;\r\n\r\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;\r\n\r\n&lt;p&gt;&lt;img alt=&quot;&quot; src=&quot;/ypCore/apps/download/image/apple_logo.jpg&quot; style=&quot;float:right; height:320px; width:320px&quot; /&gt;&lt;/p&gt;\r\n\r\n&lt;blockquote&gt;\r\n&lt;p style=&quot;text-align:center&quot;&gt;wwwwwwwwwwwwwwwwwwwwwwww&lt;/p&gt;\r\n&lt;/blockquote&gt;\r\n', 'Test', 0, 21, 0, 'admin', 1375157774, '', 0);

DROP TABLE IF EXISTS `yp_module_news_cat`;
CREATE TABLE `yp_module_news_cat` (
  `cat_id` int(10) NOT NULL AUTO_INCREMENT,
  `title` varchar(150) NOT NULL,
  `description` varchar(250) NOT NULL,
  `cat_parent_id` int(10) NOT NULL DEFAULT '0',
  `order` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`cat_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `yp_module_news_cat` VALUES
(1, 'Thông báo', 'Thông báo, tin tức mới', 0, 1),
(2, 'Tin tức', 'Tin tức, tin giới trẻ, tin thế giới...', 0, 0),
(3, 'Hệ thống', 'Thông báo mới từ hệ thống', 1, 0),
(4, 'Đội code', 'Thông tin từ đội code', 1, 0);

DROP TABLE IF EXISTS `yp_module_news_comment`;
CREATE TABLE `yp_module_news_comment` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `post_id` int(10) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  `username` varchar(150) NOT NULL,
  `email` varchar(150) NOT NULL,
  `comment` text NOT NULL,
  `date` int(10) NOT NULL,
  `like` text NOT NULL,
  `like_count` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `yp_module_news_comment` VALUES
(1, 1, 1, 'admin', '', 'Tuyệt! Phải test thử mới được!', 0, '', 0),
(2, 1, 1, 'MOD', '', 'Good Job!', 0, '', 0),
(3, 1, 5, 'admin', 'duyet2000@gmail.com', 'hello!!!!!!!', 1375110716, '', 0),
(4, 1, 5, 'admin', 'duyet2000@gmail.com', 'Goooooooooooooooooooooooooooooooooooooooooooooooo!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!', 1375110759, '', 0),
(5, 1, 5, 'admin', 'duyet2000@gmail.com', '&lt;b&gt;Google.com&lt;/b&gt;', 1375110793, '', 0),
(6, 1, 5, 'admin', 'duyet2000@gmail.com', '\r\nHOME\r\nNEWS\r\nDOWNLOAD\r\nACCOUNT\r\nCONTACT\r\nra mắt chính thức ypcore cms v1.0\r\n23/07/2013 12:39	 ·  by admin	 ·  view 187 time(s)	 ·  5 like(s) Add-this share \r\nChính thức ra mắt ypCore ampha v1.0 \r\n\r\nSau 2 tháng Code cuối cùng bản Final cũng đã hoàn thành!\r\n\r\nTag: No tag\r\ncomment\r\nComment was successfully!\r\nAccount: admin\r\nEmail: duyet2000@gmail.com\r\n   Comment\r\nlist comment\r\n admin 07:00 01/01/1970: Tuyệt! Phải test thử mới được!\r\n\r\n MOD 07:00 01/01/1970: Good Job!\r\n\r\n admin 11:11 29/07/2013: hello!!!!!!!\r\n\r\n admin 11:12 29/07/2013: Goooooooooooooooooooooooooooooooooooooooooooooooo!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\r\n\r\n admin 11:13 29/07/2013: &lt;b&gt;Google.com&lt;/b&gt;\r\n\r\nypCore v1.1.46 r6542 · (c) 2013 · Lemon9x · Facebook · Twitter · Build in 0.29166s · Explain debug\r\n', 1375110814, '', 0),
(7, 5, 0, 'Google', 'google@gmail.com', 'Test a comment from ypCore !!!', 1375111292, '', 0),
(8, 5, 5, 'admin', 'duyet2000@gmail.com', 'wwwwwwwwwwwwwwwwwwwwwww', 1375237930, '', 0),
(9, 5, 5, 'admin', 'duyet2000@gmail.com', 'Test minify', 1375252369, '', 0),
(10, 5, 5, 'admin', 'duyet2000@gmail.com', 'aaaaaaaaaaaaaaaaaaaaaaa', 1375252391, '', 0),
(11, 5, 5, 'admin', 'duyet2000@gmail.com', 'Testttttttttttttttttttttttttttttttttttttttttt minifyt', 1375257328, '', 0),
(12, 5, 0, 'XUtttt', 'duye@gamil.com', 'st Comment\r\n Google 11:21 29/07/2013: Test a comment from ypCore !!!\r\n\r\n admin 10:32 31/07/2013: wwwwwwwwwwwwwwwwwwwwwww\r\n\r\n admin 02:32 31/07/2013: Test minify\r\n\r\n admin 02:33 31/07/2013: aaaaaaaaaaaaaaaaaaaaaaa\r\n\r\n admin 03:55 31/07/2013: Testttttt', 1375261192, '', 0),
(13, 1, 7, 'google', 'googl@ggoo.com', 'fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff', 1375335856, '', 0);

DROP TABLE IF EXISTS `yp_module_news_setting`;
CREATE TABLE `yp_module_news_setting` (
  `setting` varchar(50) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`setting`)
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `yp_module_news_setting` VALUES
('allow_comment', '2'),
('captcha_lenght', '5'),
('comment_captcha', '1'),
('comment_maxchars', '500'),
('comment_minchars', '5'),
('floodchecktime', '45'),
('like_active', '1'),
('postautosave', '1'),
('postmaxchars', '100000'),
('postminchars', '10'),
('quick_edit', '0'),
('show_view_counter', '1'),
('titlemaxchars', '250');

DROP TABLE IF EXISTS `yp_module_news_tag`;
CREATE TABLE `yp_module_news_tag` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tag` varchar(250) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `yp_module_news_tag` VALUES
(1, 'thông báo'),
(2, ''),
(3, 'phỏng vấn'),
(4, 'apple'),
(5, 'test');

DROP TABLE IF EXISTS `yp_settings`;
CREATE TABLE `yp_settings` (
  `setting` varchar(50) NOT NULL,
  `value` text NOT NULL,
  `serialized` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`setting`)
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `yp_settings` VALUES
('addthis', '1', 0),
('admin_language', 'en', 0),
('cache', '1', 0),
('compression_level', '6', 0),
('compress_html', '0', 0),
('compress_page', '1', 0),
('debug', '0', 0),
('default_module', 'Index/Home', 0),
('download_path', 'source/d.png', 0),
('FACEBOOK_APP_ID', '', 0),
('FACEBOOK_SECRET', '', 0),
('fb_login', '0', 0),
('firewall', '0', 0),
('flood_check_time', '45', 0),
('google_analytics_code', 'UX-xxxxxxx', 0),
('language', 'en', 0),
('menu', 'a:1:{s:8:\"top_menu\";a:9:{i:0;a:4:{s:5:\"level\";i:1;s:9:\"parent_id\";i:0;s:4:\"text\";s:4:\"Home\";s:4:\"link\";s:1:\"/\";}i:1;a:4:{s:5:\"level\";i:1;s:9:\"parent_id\";i:0;s:4:\"text\";s:4:\"News\";s:4:\"link\";s:10:\"News/Index\";}i:2;a:4:{s:5:\"level\";i:1;s:9:\"parent_id\";i:0;s:4:\"text\";s:8:\"Download\";s:4:\"link\";s:14:\"Download/Index\";}i:3;a:4:{s:5:\"level\";i:1;s:9:\"parent_id\";i:0;s:4:\"text\";s:7:\"Account\";s:4:\"link\";s:12:\"User/Account\";}i:4;a:4:{s:5:\"level\";i:1;s:9:\"parent_id\";i:0;s:4:\"text\";s:7:\"Contact\";s:4:\"link\";s:13:\"Contact/Index\";}i:5;a:4:{s:5:\"level\";i:2;s:9:\"parent_id\";i:1;s:4:\"text\";s:8:\"Category\";s:4:\"link\";s:8:\"News/Cat\";}i:6;a:4:{s:5:\"level\";i:2;s:9:\"parent_id\";i:1;s:4:\"text\";s:11:\"Newest Post\";s:4:\"link\";s:11:\"News/Newest\";}i:7;a:4:{s:5:\"level\";i:2;s:9:\"parent_id\";i:2;s:4:\"text\";s:15:\"Download Source\";s:4:\"link\";s:15:\"Download/Source\";}i:8;a:4:{s:5:\"level\";i:2;s:9:\"parent_id\";i:2;s:4:\"text\";s:17:\"Download Software\";s:4:\"link\";s:17:\"Download/Software\";}}}', 1),
('pageview', '708', 0),
('register_active', '1', 0),
('rewrite', '1', 0),
('site_description', 'ypCore', 0),
('site_email', 'duyet2000@gmail.com', 0),
('site_keywork', 'ypcore, news', 0),
('site_title', 'ypCore System', 0),
('site_title_construct', '#TITLE# · ypCore System', 0),
('template', 'ypBootstrap', 0),
('template_list', 'a:2:{i:0;s:7:\"default\";i:1;s:11:\"ypBootstrap\";}', 1),
('tmp', '/tmp', 0),
('upload_dir', '/apps/upload', 0),
('version', 'ypCore v1.1.46 r6542', 0);

DROP TABLE IF EXISTS `yp_usergroup`;
CREATE TABLE `yp_usergroup` (
  `groupid` int(11) NOT NULL AUTO_INCREMENT,
  `groupname` varchar(20) NOT NULL,
  `description` varchar(200) NOT NULL,
  PRIMARY KEY (`groupid`)
) ENGINE=InnoDB AUTO_INCREMENT=5 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `yp_usergroup` VALUES
(1, 'Member', ''),
(2, 'Moderation', ''),
(3, 'Supper Moderation', ''),
(4, 'Administrator', '');

DROP TABLE IF EXISTS `yp_users`;
CREATE TABLE `yp_users` (
  `userid` int(11) NOT NULL AUTO_INCREMENT,
  `username` text NOT NULL,
  `password` text NOT NULL,
  `salt` varchar(10) NOT NULL,
  `full_name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `groupid` tinyint(2) NOT NULL DEFAULT '1',
  `birthday` date NOT NULL,
  `register_day` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`userid`)
) ENGINE=InnoDB AUTO_INCREMENT=8 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `yp_users` VALUES
(5, 'admin', 'de9efea127212e7a9abadf6b717eeb56', '7389AEEA88', '', 'duyet2000@gmail.com', 4, '0000-00-00', '2013-07-21 08:27:56'),
(6, 'cute_test', 'd8586a864be4e608a7a3d76bec1b2ef9', '2F4C2A704F', 'Test', 'just_test@gmail.com', 1, '0000-00-00', '2013-08-01 11:58:46'),
(7, 'google', '8e8edabd3686a86bf72bbffa28d0d7a0', '7ADFCA2F2A', 'Google.om', 'googl@ggoo.com', 1, '0000-00-00', '2013-08-01 12:02:12');

