#SKD101|ypCore|9|2014.02.01 15:07:48|106|1|12|4|14|5|62|4|4

DROP TABLE IF EXISTS `yp_download_files`;
CREATE TABLE `yp_download_files` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `path` varchar(250) NOT NULL,
  `download` int(250) NOT NULL DEFAULT '1',
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `yp_download_files` VALUES