============== COMING SOON ===============
We're yplitgroup. ypCore v1.0 is our Project.

It's was coming soon....

Thank you!

=================================================

Cảm  ơn  bạn  đã quan  tâm  đến ypCore. Nó  sẽ  sớm  hoàn  thành.
Giúp chúng  tôi? Tham gia cùng  code  với  chúng  tôi  để  cùng phát
triển project. Một cộng đồng OpenSource mới cần có bạn cùng góp 
sức.

Contact: duyet2000@gmail.com
Website: http://lemon9x.com
Cảm ơn!

                                                                                        22/07/2013
=================================================
Code: 91b60365dd3413189eca9f081b91fd8d
Bạn đã submit email, bạn sẽ nhận được thông báo sớm nhất qua email!