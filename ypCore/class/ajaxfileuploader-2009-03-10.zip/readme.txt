README:

#1) Make sure the destination directory (in my case uploaded/files/) exists in the base folder (folder where these files are)

#2) Also make sure that the destination folder(s) have read and write rights.



P.S.   EDUCATIONAL PURPOSE ONLY